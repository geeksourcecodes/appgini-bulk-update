# appgini-bulk-update
This is an appgini plugin which is simple for appgini devs to bulk update value of a single field for multiple records in their tables
